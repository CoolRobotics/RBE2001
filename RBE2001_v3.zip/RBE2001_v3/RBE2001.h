typedef enum { followLineBackwardAction,
               followLineForwardAction,
               rotateNintyDegreesAction
             } Action;

typedef enum { forwardDirection,
               backwardDirection
             } Direction;
