#include <Servo.h>

class LineFollower {
  public:
    LineFollower();
  private:
    Servo leftMotor;
    Servo rightMotor;
    
};

